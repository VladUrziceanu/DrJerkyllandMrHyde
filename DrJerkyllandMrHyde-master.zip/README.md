# DrJerkyllandMrHyde

| Name | Role |
| --- | --- |
| Cristian Rita | Project Manager |
| Adrian Salomia | Software Developer |
| Bogdan Basuc | Software Developer |
| Dragos Iancu | Software Developer |
| Vlad Urziceanu | Software Developer |
| Ioana Paun | Software Developer |
| Roxana Racu | Tester |
| Mihai Popa | Tester |
